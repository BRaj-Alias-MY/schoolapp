import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';
import { Http } from '@angular/http';
/*
  Generated class for the StudentsProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class StudentsProvider {
 URL = "http://edge-tech.info/schoolapi/getstudents.php";
 FACULTY_LOGIN_URL = "http://edge-tech.info/schoolapi/facultylogin.php";
 ATTENDANCE_URL =  "http://edge-tech.info/schoolapi/posttodayattend.php";
 SECTIONS_URL =  "http://edge-tech.info/schoolapi/getsections.php";
 PERIODS_URL =  "http://edge-tech.info/schoolapi/getperiods.php";
 PHOTO_URL =  "http://edge-tech.info/schoolapi/updatephoto.php";
  constructor(public http: Http) {
    console.log('Hello StudentsProvider Provider');
  }
  getStudents(classId:any,sectionId:any,branchId:any,schoolId:any,periodId:any): Observable<any[]> {
    return this.http.get(this.URL + '?classId='+ classId + '&sectionId='+sectionId+'&branchId='+branchId+'&schoolId='+schoolId+'&periodId='+periodId)
              .map(resp => <any[]> resp.json());
 }
facultylogin(username:string,password:string)
{
  return this.http.post( this.FACULTY_LOGIN_URL , JSON.stringify({username: username, password:password }))
  .map(response => {console.log(response); return  response ; });
}
todayAttendance(studentsData)
{
 return this.http.post(this.ATTENDANCE_URL,JSON.stringify({data:studentsData}))
        .map(response => {console.log(response); return  response ; });
}
getSections(username): Observable<any[]> {
  return this.http.get(this.SECTIONS_URL + '?username='+username)
            .map(resp => <any[]> resp.json());
}
getPeriods(classId:any,sectionId:any,branchId:any,schoolId:any): Observable<any[]> {
  return this.http.get(this.PERIODS_URL + '?classId='+ classId + '&sectionId='+sectionId+'&branchId='+branchId+'&schoolId='+schoolId)
            .map(resp => <any[]> resp.json());
}
updatePhoto(studentId,imageData)
{
  return this.http.post(this.PHOTO_URL,JSON.stringify({'studentId':studentId,'imageData': ImageData}))
  .map(response => {console.log(response); return  response ; });
}

uploadPic(studentId:string,imgData:any)
{
  return this.http.post( this.PHOTO_URL , JSON.stringify({studentId: studentId, imgData:imgData }))
  .map(response => {console.log(response); return  response ; });
}
}
