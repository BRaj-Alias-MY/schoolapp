import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,App } from 'ionic-angular';
import { HomePage } from '../home/home';
import { AttendancePage } from '../attendance/attendance';
import { Http} from '@angular/http';
import {StudentsProvider} from '../../providers/students/students';
import { TakeattendancePage } from '../takeattendance/takeattendance';
import { ToastController, LoadingController } from 'ionic-angular';
import { ClasslistPage } from '../classlist/classlist';
/**
 * Generated class for the FacultyloginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-facultylogin',
  templateUrl: 'facultylogin.html',
})
export class FacultyloginPage {
 username: string = '';
 password: string = '';
 result: any;
 loading;
 facultyId: string = '' ;

  constructor(public loadingCtrl: LoadingController,public navCtrl: NavController, public navParams: NavParams,public app:App, public http:Http, public studentService: StudentsProvider,private toastCtrl: ToastController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FacultyloginPage');
  }
  gotoHome(){
    this.navCtrl.push(HomePage);
  }
  facultyLogin(formdata: any){
   this.loadingPresent();
       this.username = formdata['username'];
       this.password = formdata['password'];
     this.studentService.facultylogin(this.username,this.password)
     .subscribe(res => {this.result = res['_body']; if(this.result!='fail') { console.log(this.result); localStorage.setItem('schoolId',this.result); localStorage.setItem('loginUser',this.username); this.navCtrl.push(ClasslistPage)} else { this.errorToast();}}, error => {this.result = error['_body']; },()=>this.loadingAbsent())
     if(this.result!='fail')
     {
          console.log('you are welcome');
     }
     else
     {
         console.log('not okay');
     }
  }
  errorToast() {
    let toast = this.toastCtrl.create({
      message: 'Oops ! Wrong Credentials..',
      duration: 3000,
      position: 'top'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }

  //loading pannel
  loadingPresent() {

    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
     this.loading.present();


  }
  loadingAbsent(){

      this.loading.dismiss();

  }


}
