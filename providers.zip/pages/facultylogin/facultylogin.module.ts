import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FacultyloginPage } from './facultylogin';

@NgModule({
  declarations: [
    FacultyloginPage,
  ],
  imports: [
    IonicPageModule.forChild(FacultyloginPage),
  ],
})
export class FacultyloginPageModule {}
