import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhotocapturePage } from './photocapture';

@NgModule({
  declarations: [
    PhotocapturePage,
  ],
  imports: [
    IonicPageModule.forChild(PhotocapturePage),
  ],
})
export class PhotocapturePageModule {}
