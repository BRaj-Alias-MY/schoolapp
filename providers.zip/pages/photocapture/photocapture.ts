import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, App, AlertController, LoadingController, ToastController } from 'ionic-angular';

import { StudentsProvider } from '../../providers/students/students';
import {Http,Response,Request,Headers} from  '@angular/http';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { TakeattendancePage } from '../takeattendance/takeattendance';
/**
 * Generated class for the PhotocapturePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-photocapture',
  templateUrl: 'photocapture.html',
})
export class PhotocapturePage implements OnInit {
imagePath:any;
imageStatus:any;
loading:any;
photoStudentId = localStorage.getItem('photoStudentId');
photoClassName = localStorage.getItem('photoClassName');
photoSectionName = localStorage.getItem('photoSectionName');
photoStudentName = localStorage.getItem('photoStudentName');
  constructor(private loadingCtrl:LoadingController, private toast:ToastController, private camera:Camera, private studentService:StudentsProvider, public navCtrl: NavController, public navParams: NavParams, public app:App) {
  }
 ngOnInit(): void {
  console.log(this.photoStudentId);
  this.photoStudentId = localStorage.getItem('photoStudentId');
  this.photoClassName = localStorage.getItem('photoClassName');
  this.photoSectionName = localStorage.getItem('photoSectionName');
  this.photoStudentName = localStorage.getItem('photoStudentName');
 }
 goback(){
   this.navCtrl.push(TakeattendancePage);
 }
  ionViewDidLoad() {
    console.log('ionViewDidLoad PhotocapturePage');
  }
  takePhoto(){
    const options: CameraOptions = {
      quality: 50,
      correctOrientation: true,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    }
    this.camera.getPicture(options).then((imageData) => {
      // imageData is either a base64 encoded string or a file URI
      // If it's base64:
      let base64Image = 'data:image/jpeg;base64,' + imageData;
       this.imagePath = base64Image;

     }, (err) => {
      // Handle error
     });
     console.log('trail photo');
  }
  updatePhoto(){
    this.loadingPresent();
    console.log(this.photoStudentId);
    this.studentService.uploadPic(this.photoStudentId,this.imagePath).subscribe(res => {this.imageStatus = res['_body'] ; if(this.imageStatus =='Inserted'){ this.successToast();} else { this.errorToast();}}, error => {this.errorToast(); },()=>this.loadingAbsent());

  }
process(){

}
loadingPresent() {

          this.loading = this.loadingCtrl.create({
            content: 'Loading...'
          });
           this.loading.present();


        }
        loadingAbsent(){

            this.loading.dismiss();

        }

        successToast() {
          let toast = this.toast.create({
            message: 'Photo Updated Successfully..!',
            duration: 3000,
            position: 'top'
          });

          toast.onDidDismiss(() => {
            console.log('Dismissed toast');
          });

          toast.present();
        }

        errorToast() {
          let toast = this.toast.create({
            message: 'Oops ! Error..',
            duration: 3000,
            position: 'top'
          });

          toast.onDidDismiss(() => {
            console.log('Dismissed toast');
          });

          toast.present();
        }
}
