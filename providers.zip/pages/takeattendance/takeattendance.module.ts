import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TakeattendancePage } from './takeattendance';

@NgModule({
  declarations: [
    TakeattendancePage,
  ],
  imports: [
    IonicPageModule.forChild(TakeattendancePage),
  ],
})
export class TakeattendancePageModule {}
