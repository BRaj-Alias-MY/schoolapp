import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminloginPage } from './adminlogin';

@NgModule({
  declarations: [
    AdminloginPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminloginPage),
  ],
})
export class AdminloginPageModule {}
