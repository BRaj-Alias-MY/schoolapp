import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, App , ToastController, LoadingController,AlertController  } from 'ionic-angular';
import { Http} from '@angular/http';
import {StudentsProvider} from '../../providers/students/students';
import { } from 'ionic-angular';
import { TakeattendancePage } from '../takeattendance/takeattendance';
import { PeriodpagePage } from '../periodpage/periodpage';
import { FacultyloginPage } from '../facultylogin/facultylogin';
@IonicPage()
@Component({
  selector: 'page-classlist',
  templateUrl: 'classlist.html',
})
export class ClasslistPage implements OnInit {
 classes: any;
 loading;
 username =  localStorage.getItem('loginUser');
 btncolor : any;

 color:any;
  constructor(private alertCtrl: AlertController,public loadingCtrl: LoadingController,private toastCtrl: ToastController,public app: App, public navCtrl: NavController, public navParams: NavParams, public http:Http, public studentService: StudentsProvider) {

  }
  ngOnInit(): void {
    this.getSections();
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad ClasslistPage');
  }
  getSections()
  {
    this.loadingPresent();
  this.studentService.getSections(this.username).subscribe(resp=>{ this.classes  = resp; console.log(this.classes)  },err=>{console.log('Unable to Load Data')},()=>this.loadingAbsent());
  }
  getAttendance(classId,sectionId,className,sectionName)  {

      localStorage.setItem('classId',classId);
      localStorage.setItem('sectionId',sectionId);
      localStorage.setItem('myClassName',className);
      localStorage.setItem('mySectionName',sectionName);
      console.log(classId + '/' + sectionId);
     // this.navCtrl.push(TakeattendancePage);
     this.navCtrl.push(PeriodpagePage);
  }
  presentConfirm() {
    let alert = this.alertCtrl.create({
      title: 'Are you Sure?',
      message: 'You will be logging out....!',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Logout',
          handler: () => {
           this.goback();
          }
        }
      ]
    });
    alert.present();
  }

  goback(){
    this.navCtrl.push(FacultyloginPage);
  }
  /*
  errorToast() {
    let toast = this.toastCtrl.create({
      message: 'Oops ! Wrong Credentials..',
      duration: 3000,
      position: 'top'
    });

    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
    });

    toast.present();
  }
*/
  //loading pannel
  loadingPresent() {

    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
     this.loading.present();


  }
  loadingAbsent(){

      this.loading.dismiss();

  }
}
