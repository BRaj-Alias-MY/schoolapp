import { Component } from '@angular/core';
import { NavController, App } from 'ionic-angular';
import { AdminloginPage } from '../adminlogin/adminlogin';
import { FacultyloginPage } from '../facultylogin/facultylogin';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController ,public app:App) {

  }
  adminlogin(){
     this.navCtrl.push(AdminloginPage)
  }
  facultyLogin(){
    localStorage.setItem('branchId','1');
    this.navCtrl.push(FacultyloginPage)
 }

}
