import { Component,OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams, App , ToastController, LoadingController } from 'ionic-angular';
import { Http} from '@angular/http';
import {StudentsProvider} from '../../providers/students/students';
import { TakeattendancePage } from '../takeattendance/takeattendance';
import { ClasslistPage } from '../classlist/classlist';
/**
 * Generated class for the PeriodpagePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-periodpage',
  templateUrl: 'periodpage.html',
})
export class PeriodpagePage implements OnInit{
 classId = localStorage.getItem('classId');
 sectionId = localStorage.getItem('sectionId');
 branchId = localStorage.getItem('branchId');
 schoolId = localStorage.getItem('schoolId');
 loading:any;
 periods:any;

  constructor(public app:App,public studentService: StudentsProvider,public loadingCtrl: LoadingController,public http:Http, public navCtrl: NavController, public navParams: NavParams) {
  }
 ngOnInit(): void {
this.getPeriods();

 }
  ionViewDidLoad() {
    console.log('ionViewDidLoad PeriodpagePage');
  }

  getPeriods()
  {

    this.loadingPresent();
    this.studentService.getPeriods(this.classId,this.sectionId,this.branchId,this.schoolId).subscribe(resp=>{ this.periods  = resp; console.log(this.periods)  },err=>{console.log('Unable to Load Data')},()=>this.loadingAbsent());


  }
  gotoAttendance(periodId,periodName)
  {
 localStorage.setItem('periodId',periodId);
 localStorage.setItem('periodName',periodName);
 this.navCtrl.push(TakeattendancePage);
  }
  goback(){
    this.navCtrl.push(ClasslistPage);
  }
  loadingPresent() {

        this.loading = this.loadingCtrl.create({
          content: 'Please wait...'
        });
         this.loading.present();


      }
      loadingAbsent(){

          this.loading.dismiss();

      }

}
