import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PeriodpagePage } from './periodpage';

@NgModule({
  declarations: [
    PeriodpagePage,
  ],
  imports: [
    IonicPageModule.forChild(PeriodpagePage),
  ],
})
export class PeriodpagePageModule {}
