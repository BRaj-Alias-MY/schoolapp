import { Component, OnInit } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';


/**
 * Generated class for the AttendancePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-attendance',
  templateUrl: 'attendance.html',
})
export class AttendancePage implements OnInit{
  colorClass : string = 'presentClass';
  att_status_3 :string;
  status_val : string = 'P';

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }
  ngOnInit(): void {

    this.att_status_3 = "presentClass";
    this.status_val = 'P';
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AttendancePage');
  }
  changeAbsent(className)
  {
    this.colorClass = className;
    this.att_status_3 = "absentClass";
    this.status_val = 'A';
    console.log(this.colorClass);

  }
  changePresent(className)
  {
    this.colorClass = className;
    this.att_status_3 = "presentClass";
    console.log(this.colorClass);
    this.status_val = 'P';
  }

}
