import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { AdminloginPage } from '../pages/adminlogin/adminlogin';
import { FacultyloginPage } from '../pages/facultylogin/facultylogin';
import { AttendancePage } from '../pages/attendance/attendance';
import { TakeattendancePage } from '../pages/takeattendance/takeattendance';
import { ClasslistPage } from '../pages/classlist/classlist';
import { PeriodpagePage } from '../pages/periodpage/periodpage';
import { PhotocapturePage } from '../pages/photocapture/photocapture';
import { HttpModule} from '@angular/http';
import { StudentsProvider } from '../providers/students/students';
import {FormsModule} from '@angular/forms';
import { Camera, CameraOptions } from '@ionic-native/camera';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    AdminloginPage,
    FacultyloginPage,
    AttendancePage,
    TakeattendancePage,
    ClasslistPage,
    PeriodpagePage,
    PhotocapturePage


  ],
  imports: [
    BrowserModule,HttpModule,FormsModule,

    IonicModule.forRoot(MyApp)
  ],

  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    AdminloginPage,
    FacultyloginPage,
    AttendancePage,
    TakeattendancePage,
    ClasslistPage,
    PeriodpagePage,
    PhotocapturePage
  ],
  providers: [
    StatusBar,
    Camera,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    StudentsProvider
  ]
})
export class AppModule {}
